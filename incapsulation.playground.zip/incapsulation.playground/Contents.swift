import UIKit

class Wallet{
  private  var balance = 0
    
    func add(cash:Int){
        self.balance += cash
        print("Вы внесли сумму размером: \(cash)")
    }
    func down(cash:Int) -> Int{
        guard cash <= balance else{
            print("Вы хотите снять деньги в колличестве: \(cash)")
            print("Вы не можете остаться должны банку!")
            return 0
        }
        self.balance -= cash
        return cash
    }
    func getbalance() ->Int{
        print("Ваш баланс равен")
        return self.balance
    }
}

var wallet = Wallet()

wallet.add(cash: 60)
wallet.down(cash: 70)

print(wallet.getbalance())
