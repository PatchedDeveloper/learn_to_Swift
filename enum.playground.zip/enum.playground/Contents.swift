import UIKit

enum DayTime{
    
    case night
    case morning
    case afternoon
    case evening
}

var currentTime = DayTime.evening

currentTime = .night
let day: DayTime = .afternoon

switch currentTime{
    
case .night:
    print("Ночь")
case .morning:
    print("Утро")
case .afternoon:
    print("день")
case .evening:
    print("Вечер")
}

enum Professional{
    case Programmer(String,String,Int)
    case sysAdmin(String,String)
    case webDesigner(String,Int)
    case cleaningManager(String)
}


let myprofessiom = Professional.Programmer("Danila", "Ios", 6)
let designer = Professional.webDesigner("Damir", 13)


func check(prof: Professional){
   
    switch prof{
    case .Programmer(let name,let specialite, let opyt):
        print("Меня зовут \(name) я работаю \(specialite) вот уже \(opyt)")
    case .sysAdmin(let name, let spec):
        print("Меня зовут \(name) работаю сисадмином, спциализируюсь на \(spec)")
    case .webDesigner(_, _):
        print("web")
    case .cleaningManager(_):
        break
    }
}

check(prof: myprofessiom)
check(prof: designer)


// clear Var

enum MyPetName:String, CaseIterable{
  case  cat = "Мурзик"
   case dog = "Тузик"
     case rabbit = "Маруся"
    case bat = "Ночнушка"
}

var myCat = MyPetName.cat

var myCatName = myCat.rawValue

var myPets = MyPetName.allCases

print(myPets)

for pet in myPets{
    print(pet.rawValue)
}

enum Season:Int{
    case winter = 1,spring,summer, autumn
    
    var label:String{
        switch self{
            
        case .winter:
            return "Зима"
        case .spring:
            return "Весна"
        case .summer:
            return "Лето"
        case .autumn:
            return "Осень"
        }
    }
    var int:Int{return 5}
    
    init?(_ value: String) {
        switch value{
        case "Зима": self = .winter
        case "Весна": self = .spring
        case "Лето": self = .summer
        case "Осень": self = .autumn
        default: return nil
        }
    }
    func printlabel(){
        print(self.label)
    }
}

let season = Season("Лето")

season?.printlabel()


