import UIKit

// Polimorphism

class Teacher {
    let name:String
    
    var description:String{
        return "hello my name \(name) i'm teacher."
}
    
    init(name:String){
        self.name = name
    }
    
    func studies(){
        print("я учу людей прямо сейчас!")
    }
}

class iosteacher: Teacher {
    
    let speciality:String
    
    override var description: String{
        return "hello my name \(name) i'm teacher for SWIFT"
    }
    
    init(name:String, speciality:String){
        self.speciality = speciality
        super.init(name: name)
    }
    override init(name: String) {
        self.speciality = "Frontend"
        super.init(name: name)
    }
    
    func swiftcoding(){
        print("Я прогаю на свифт!")
    }
    override func studies() {
        print("я учу ios разработке  прямо сейчас!")
    }
    func teach(hours:Int){
        
        print("Я учу людей уже \(hours) часов!")
    }
}

let teacher = Teacher(name: "Вася")

teacher.name
teacher.description
teacher.studies()

let IOSteacher = iosteacher(name: "Валентин", speciality: "Фронт")

IOSteacher.speciality
IOSteacher.swiftcoding()
IOSteacher.name
IOSteacher.description

let iosteacher2 = iosteacher(name: "Andrey ")
iosteacher2.studies()
iosteacher2.description
iosteacher2.studies()
iosteacher2.teach(hours: 5)

