import UIKit

//euatable - равно/неравно
// comparable - <> <= >= == !=
//CustomStringConvertible - могут быть представлены ввиде строки
// numeric - все все числа




// generics

func addInts(a:Int, b:Int)->Int{
    return a + b
}

func addDoubles(a:Double,b:Double)->Double{
    return a + b
}

func add<T: Numeric >(a:T,b:T)->T{
    return a + b
}

add(a: 56, b: 23)
add(a: 56.3, b: 23.9)


protocol Storage{
    associatedtype Item
    func store (item:Item)
    func retrive(index: Int)-> Item?
}

struct book {
    let title: String
    let author: String
}

class BookCase: Storage {
    
    typealias Item = book
    
    var books = [book]()
    
    func store (item:book){
        books.append(item)
    }
    func retrive(index: Int) -> book? {
        guard index < books.count else {return nil}
        
        return books[index]
    }
    
}

class Case<Item>: Storage {
    
    var items = [Item]()
    
    func store (item:Item){
        items.append(item)
    }
    func retrive(index: Int) -> Item? {
        guard index < items.count else {return nil}
        
        return items[index]
    }
}


struct clothes{
let brens:String
let price:Int
let size:String
}

let tShort = clothes(brens: "Versache", price: 1000, size: "L")
let shoes = clothes(brens: "Nike", price: 200, size: "39")


let clothesCase = Case<clothes>()

clothesCase.store(item: tShort)
clothesCase.store(item: shoes)

clothesCase.items.count
clothesCase.items.last?.price
clothesCase.items.last?.brens

//stack

struct stack <T>{
    private var conteiner = [T]()
    
    var isEmpty: Bool {
        return self.conteiner.isEmpty
    }
    var size:Int{return self.conteiner.count}
    var top : T? {return self.conteiner.last}
    
    
    mutating func push(_ element : T) {
        self.conteiner.append(element)
    }
    
    mutating func pop()->T?{
        if !self.isEmpty{return conteiner.removeLast()}
        else {return nil}
        
    }
}


var Stack = stack<String>()

Stack.push("ANNA KARENINA")
Stack.push("Cat Leopold")
Stack.push("Buratino")
Stack.size
Stack.isEmpty
Stack.top
Stack.pop()
Stack.top
Stack.size
