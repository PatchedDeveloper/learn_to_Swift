import UIKit
import Foundation
//vvod
let Chislo: Float = 4

let label = "The width is "
let width = 94
let widthLabel = label + String(width)

//vivod dannih i opredelenie
let  oranges = 5
let apples = 4
let OrangePlusApples = "Получилось summa \(oranges+apples)"
//massiv and cortage
var shoplist = ["mango", "tango","bottle"]
shoplist[1] = "Mak"
print(shoplist)

var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",
]
occupations["Jayne"] = "Public Relations"
print(occupations
)

shoplist.append("worked")
print(shoplist)

let individualScores = [22, 43, 13, 57, 12]
var teamScore = 0
for score in individualScores {
    if score > 50 {
        teamScore += 3
    } else {
        teamScore += 1
    }
}
print(teamScore)
// optional types
var optionalName: String? = nil
var greeting = "Hello!"
if let name = optionalName {
    greeting = "Hello, \(name)"
}
else {
    greeting = "hi guest! "
}
print (greeting)

let nickName: String? = "Danila"
let fullName: String = "John Appleseed"
let informalGreeting = "Hi \(nickName ?? fullName)"
//case
let vegetable = "Привет"
switch vegetable {
case "Привет":
    print("И тебе привет")
case "пока", "бай":
     print("пока")
default:
     print("Я не понимаю")
}

let interestingNumbers = [
    "Prime": [2, 3, 5, 7, 11, 13],
    "Fibonacci": [1, 1, 2, 3, 5, 8],
    "Square": [1, 4, 9, 16, 25],
]
var largest = 0
for (_, numbers) in interestingNumbers {
    for number in numbers {
        if number > largest {
            largest = number
        }
    }
}
print(largest)

var n = 2
while n < 100 {
    n *= 2
}
print(n)

var m = 2
repeat {
    m *= 2
} while m < 100
print(m)

var firstForLoop = 0
for i in 0..<4 {
    firstForLoop += i
}
print(firstForLoop)
// function and zamikaniya

func greet(_ name:String,_ foodday:String )-> String {
return("Hello \(name), food day \(foodday)")
}
greet("Danila","beef")

func calculateStatistics(scores: [Int]) -> (min: Int, max: Int, sum: Int) {
    var min = scores[0]
    var max = scores[0]
    var sum = 0
    
    for score in scores {
        if score > max {
            max = score
        } else if score < min {
            min = score
        }
        sum += score
    }
    
    return (min, max, sum)
}
let statistics = calculateStatistics(scores: [5, 3, 100, 3, 9])

print(statistics.sum)
print(statistics.2)


class Shape {
    let numberOfSides = 0
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
}













//class///////

class player {
    
    let name: String
    var level : Int = 0
    
    init(name: String){
        self.name = name
    }
    
    init(name:String = "User",level: Int = 0){
        self.level = level
        self.name = name
    }
    
    func printinfo(){
        print("Имя игрока: \(self.name) Уровень: \(self.level)")
    }
    
    func levelUp(count : Int){
        self.level += count
    }
    
    func levelDown(count : Int){
        guard count<self.level else {
            self.level=0
            return
        }
        self.level -= count
    }
    
}
var player1 = player(name: "Danila")
player1.level = 11
player1.levelDown(count: 5)
player1.level
player1.printinfo()
var player2 = player(name: "Alexey")
player2.levelUp(count: 1)
player2.level
player2.printinfo()
var player3 = player()


var players: [player] = [player1,player2,player3]

for player in players{
    print(player.name)
}


//Свойства



class salesManager{
    
    static var phones = "Iphone Se 2"
    class var companyName:String {return "Patched"}
    
    
    var salarybaze = 15000
    var call = 0{
        willSet{
            print("Вы совершили звонков \(newValue). Предыдущее значение  \(call)")
        }
        didSet{
            if call >= 130{
                print("Ура звонков теперь \(call)")
                
            }
            
        }
    }
    
    
    
    
    
    var salesamount = 0
    {
        willSet{
            print("Вы продали товара на \(newValue). Предыдущее значение  \(salesamount)")
        }
        didSet{
            if salesamount >= 300000{
                print("Ура сумма продаж \(salesamount)")
                
            }
           
        }
    }
    var sanctionsamount = 0
    
    lazy var userImage = UIImage()
    
    
    var motivation: Int {
        
        if ((call >= 130) && (salesamount >= 300000)){
            
            let motiv = call * 50 + (salesamount * 12/100)
            
            return motiv
        }
        else{
            return 0
        }
        
        var sallary: Int {
            
            var result = salarybaze + motivation - sanctionsamount
            
            guard result >= salarybaze else{
                result = salarybaze / 2
                return result
            }
            
            return result
        }
    }
}

 let fedya = salesManager()
fedya.salarybaze
fedya.salarybaze
fedya.motivation
salesManager.phones = "Iphone xr"
salesManager.phones
fedya.userImage
fedya.salesamount = 30000
fedya.salesamount = 400000
fedya.call = 10
fedya.call = 150






//initializations
class car {
    let brandModel: String
    let Wheelscount:Int
    var color:String = "White"
    init(brandModel:String ,Wheelscount:Int = 4 ){
        self.brandModel = brandModel
        self.Wheelscount = Wheelscount
    }
    
    //memberWise-init
    init(brandModel:String ,Wheelscount:Int ,color: String ){
        self.brandModel = brandModel
        self.Wheelscount = Wheelscount
        self.color = color
    }
    //FailInit
    
    init?(brend:String,model:String,Wheelscount:Int ){
        if Wheelscount < 4 {
            return nil
        }
        else{
            self.Wheelscount = Wheelscount
            self.brandModel = "\(brend) \(model)"
        }
    }
    
    //Удобный инициализатор
    convenience init(brandModel:String,  color: String) {
        self.init(brandModel: brandModel)
    }
    
    let mercedes = car(brandModel: "Mersedes Benz AMG ")
    let audi = car(brandModel:"Audi a4", Wheelscount: 6)
    
    
    
    
}



//Принципы ооп


class Vehical {
    
    let brend:String
    let massa: Int
    init(brend:String , massa: Int){
        self.brend = brend
        self.massa = massa
    }
    func go(){
        print("Its going")
    }
    
    let vehical = Vehical(brend: "Stels", massa: 12)
}

class Car:Vehical {
    
    
    let cartype:String
    let enginpower:Int
    
    init(brend:String,massa: Int,cartype:String,enginpower:Int){
        self.cartype = cartype
        self.enginpower = enginpower
        super.init(brend: brend, massa: massa)
        
    }
    
    func klakson(){
        print("Beep-Beep")
    }
    
    
}
let BMW = Car(brend: "BMW", massa: 1300, cartype: "hATCHBACK", enginpower: 400)
let audi = Car(brend: "AUDI", massa: 1200, cartype: "CITY", enginpower: 1200)

var cars: [Car] = [BMW,audi]

class SportCar: Car {
    
    let maxspeed:Int
    
    init(brend:String,massa: Int,enginpower:Int, maxspeed:Int){
        self.maxspeed = maxspeed
        super.init(brend: brend, massa: massa, cartype: "sportcar", enginpower: enginpower)
    }
}

let ferrari = SportCar(brend: "Ferrari", massa: 1800, enginpower: 430, maxspeed: 340)
let porshe = SportCar(brend: "Porshe", massa: 1700, enginpower: 370, maxspeed: 320)

BMW.klakson()
BMW.go()
BMW.cartype
