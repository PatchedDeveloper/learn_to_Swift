import UIKit

//Protocols

protocol FullyNamed{
    
    var fullname: String {get}
}

struct Person: FullyNamed{
    var fullname: String
    var age: Int
    var phone: Int
}

class company: FullyNamed{
    var fullname: String
    
    init(prefix:String,title:String){
        self.fullname = "\(prefix) \(title)"
    }
}

let misha = Person(fullname: "Mihail", age: 38, phone: 88005555535)
let alisa = Person(fullname: "Alisa", age: 27, phone: 89271203467)
let apple = company(prefix: "LLC", title: "Apple")
let google = company(prefix: "LLC", title: "Google")

class Bank: company{
    var clients = [FullyNamed]()
}

let bank = Bank(prefix: "OOO", title: "ALPHAbank")

bank.clients.append(misha)
bank.clients.append(alisa)
bank.clients.append(apple)
bank.clients.append(google)

for client in bank.clients{
    print(client.fullname)
}
