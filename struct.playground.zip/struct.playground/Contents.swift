import UIKit

class Person{
    let name:String
    var phone: Int
    
    init(name:String,phone:Int){
        self.name = name
        self.phone = phone
    }
    
    func change(phone:Int ){
        self.phone = phone
        
    }
}

struct User{
    let name:String
    var phone: Int
    
   mutating func change(phone:Int ){
        self.phone = phone
        
    }
}

let person = Person(name: "Vasua", phone: 89603568007)
let user = User(name: "Alex", phone: 88003561143)
let persone2 = Person(name: "Danila", phone: 88005555535)
var user2 = User(name: "Mriya", phone: 89063017053)

person.phone = 89274301275//хранит ссылку Person и в классе меняет значение
//user.phone = 89272296102 - Error! //User - хранит не ссылку а значение!
            
user2 = user

user2.name
user.name
